import scrapy
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import CrawlSpider, Rule


class YelpCrawlSpider(CrawlSpider):
    name = 'data'

    start_urls = ['https://www.wolfspeed.com/products/rf/aerospace-defense']






    le_yelp_details = LinkExtractor(restrict_xpaths='//a[@class=" css-3rbc47 eu0m35q1"]')
    #le_yelp_links = LinkExtractor(restrict_xpaths='//a[@class=" css-3rbc47 eu0m35q1"]')

    rule_yelp_details = Rule(le_yelp_details, callback='parse_item', follow=True)
    rules = (
        rule_yelp_details,
    )
    # rule_yelp_links = Rule(le_yelp_links, callback='parse_item', follow=True)
    # rules = (
    #     rule_yelp_links,
    # )
    # rule_next = Rule(le_next, follow=True)
    rules = (
         rule_yelp_details,
         # rule_yelp_links
     )

    def parse_item(self, response):
        yield {
            'Link':response.xpath('..//@href').get(),
            'skuname': response.xpath('//div[@class="css-a2iyqi eu0m35q2"]/text()')[0].get(),
            'Product_skuname':response.xpath('//*[@id="gatsby-focus-wrapper"]/div/main/section[2]/div/div/div[2]/table/tbody/tr/td[1]/div/text()').getall(),

            'Title': response.xpath('//h1[@class="css-1cksn0v e1wnoik18"]/text()').get(),
            'Category': response.xpath('//*[@id="gatsby-focus-wrapper"]/div/header/div/div/div[2]/nav/div[1]/div/div[2]/a[1]/text()').get(),

            'Sub_Category': response.xpath('//*[@id="gatsby-focus-wrapper"]/div/header/div/div/div[2]/nav/div[1]/div/div[2]/a[2]/text()').get(),
            'Short_Description': response.xpath('//div[@class="css-rdzm60 e1wnoik17"]/text()').get(),
            'Description': response.xpath('//div[@class="e1wnoik15 css-9ygu6y e1r8dk820"]//p/text()').get(),
            'Document_type': response.xpath('//td[@class="css-1t7s8z3 eq5psfl7"]/text()').getall(),
            'Document_Name': response.xpath('//span[@class="css-v68xts e113pav02"]/text()').getall(),
            'Features': response.xpath('//*[@id="gatsby-focus-wrapper"]/div/main/section[3]/div/div/div[1]/article/div[2]/ul/li/text()').getall(),
            'Application': response.xpath('//*[@id="gatsby-focus-wrapper"]/div/main/section[3]/div/div/div[2]/article/div[2]/ul/li/text()').getall(),

            'Images': response.xpath('//picture//img/@src')[0].get(),



        }



